import Foundation
import UIKit


let kDebugLog = true

// AirPlayButton Color
let globalTintColor = UIColor(red: 0, green: 189/255, blue: 233/255, alpha: 1);


let useLocalStations = true
let stationDataURL   = "http://yoururl.com/json/stations.json"

let searchable = false

let hideNextPreviousButtons = true

let hideAirPlayButton = false
